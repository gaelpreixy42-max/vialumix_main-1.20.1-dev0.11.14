package com.vialumix.screen;

import com.vialumix.client.VialumixClient;
import com.vialumix.config.VialumixConfig;
import com.vialumix.rt.VialumixNative;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;

public final class VialumixScreen extends class_437 {
    private final class_437 parent;
    private final VialumixConfig cfg;
    private final int panelWidth = 420;
    private class_4185 shaderButton;
    private class_4185 resolutionButton;
    private class_4185 renderDistanceButton;
    private class_4185 graphicsQualityButton;
    private class_4185 dlssButton;

    public VialumixScreen(class_437 parent) {
        super(class_2561.method_43471("vialumix.title"));
        this.parent = parent;
        this.cfg = VialumixClient.config().copy();
        if (cfg.shaderpack == null || cfg.shaderpack.isBlank()) {
            cfg.shaderpack = VialumixClient.shaderpacks().currentSelection();
        }
    }

    @Override
    protected void method_25426() {
        int left = (field_22789 - panelWidth) / 2;
        int y = 48;

        resolutionButton = method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.graphics.resolution").method_27693(": ").method_10852(resolutionText()),
                b -> cycleResolution()
        ).method_46434(left, y, panelWidth, 24).method_46431());
        y += 31;

        renderDistanceButton = method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.graphics.render_distance").method_27693(": ").method_27693(Integer.toString(cfg.renderDistance)),
                b -> cycleRenderDistance()
        ).method_46434(left, y, panelWidth, 24).method_46431());
        y += 31;

        graphicsQualityButton = method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.graphics.quality").method_27693(": ").method_10852(graphicsQualityText()),
                b -> cycleGraphicsQuality()
        ).method_46434(left, y, panelWidth, 24).method_46431());
        y += 38;

        shaderButton = method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.shaderpack")
                        .method_27693(": ")
                        .method_27693(VialumixClient.shaderpacks().displayName(cfg.shaderpack)),
                b -> openShaderpackSelection()
        ).method_46434(left, y, panelWidth, 24).method_46431());
        y += 31;

        class_5676<Boolean> rayTracingButton = method_37063(class_5676.method_32614()
                .method_32619(cfg.rayTracing)
                .method_32617(left, y, panelWidth, 24, class_2561.method_43471("vialumix.rt.bliss_screen_mode"), (button, value) -> {
                    if (VialumixNative.isRadianceBackendAvailable()) {
                        button.method_32605(true);
                        VialumixClient.notify("vialumix.rt.mcvr_always_active");
                        return;
                    }
                    if (value) {
                        if (!VialumixNative.supportsRayTracing()
                                && !VialumixClient.shaderpacks().supportsVialumixTracing(cfg.shaderpack)) {
                            button.method_32605(false);
                            VialumixClient.notify("vialumix.rt.bliss_required");
                            return;
                        }
                    }
                    cfg.rayTracing = value;
                    cfg.backend = VialumixNative.supportsRayTracing() && value ? "vulkan" : "iris";
                }));
        if (VialumixNative.isRadianceBackendAvailable()) rayTracingButton.field_22763 = false;
        y += 31;

        int halfWidth = (panelWidth - 8) / 2;
        addToggle(left, y, halfWidth, "vialumix.rt.shadows", () -> cfg.rayTracedShadows, v -> cfg.rayTracedShadows = v);
        addToggle(left + halfWidth + 8, y, halfWidth, "vialumix.rt.reflections", () -> cfg.rayTracedReflections, v -> cfg.rayTracedReflections = v);
        y += 31;
        addToggle(left, y, halfWidth, "vialumix.rt.gi", () -> cfg.rayTracedGI, v -> cfg.rayTracedGI = v);
        addToggle(left + halfWidth + 8, y, halfWidth, "vialumix.rt.ao", () -> cfg.rayTracedAO, v -> cfg.rayTracedAO = v);
        y += 31;
        addToggle(left, y, halfWidth, "vialumix.rt.denoiser", () -> cfg.denoiser, v -> cfg.denoiser = v);
        addToggle(left + halfWidth + 8, y, halfWidth, "vialumix.rt.reconstruction", () -> cfg.rayReconstruction, v -> {
            if (v && !VialumixNative.supportsRayReconstruction()) {
                VialumixClient.notify("vialumix.dlss.rr_missing");
                return;
            }
            cfg.rayReconstruction = v;
        });
        y += 31;

        dlssButton = method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.upscaler").method_27693(": ").method_10852(upscalerText()),
                b -> cycleUpscaler()
        ).method_46434(left, y + 6, panelWidth, 24).method_46431());
        if (VialumixNative.isRadianceBackendAvailable()) dlssButton.field_22763 = false;
        y += 37;

        class_4185 dlssQualityButton = method_37063(class_4185.method_46430(class_2561.method_43471("vialumix.dlss.quality").method_27693(": ").method_27693(cfg.dlssQuality), b -> cycleDlssQuality())
                .method_46434(left, y, panelWidth, 24).method_46431());
        if (VialumixNative.isRadianceBackendAvailable()) dlssQualityButton.field_22763 = false;
        y += 31;

        class_5676<Boolean> frameGenerationButton = method_37063(class_5676.method_32614()
                .method_32619(cfg.frameGeneration)
                .method_32617(left, y, panelWidth, 24, class_2561.method_43471("vialumix.frame_generation"), (b, value) -> {
                    if (value && !VialumixNative.supportsFrameGeneration()) {
                        VialumixClient.notify("vialumix.dlss.fg_missing");
                        b.method_32605(false);
                        return;
                    }
                    cfg.frameGeneration = value;
                }));
        if (VialumixNative.isRadianceBackendAvailable()) frameGenerationButton.field_22763 = false;
        y += 40;

        method_37063(class_4185.method_46430(class_2561.method_43471("vialumix.apply"), b -> applyAndClose())
                .method_46434(left, y, (panelWidth - 8) / 2, 24).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), b -> field_22787.method_1507(parent))
                .method_46434(left + (panelWidth + 8) / 2, y, (panelWidth - 8) / 2, 24).method_46431());
    }

    private void applyAndClose() {
        boolean radiance = VialumixNative.isRadianceBackendAvailable();
        if (!radiance && "iris".equalsIgnoreCase(cfg.backend)) {
            boolean queued = VialumixClient.shaderpacks().applyVialumixOptions(cfg.shaderpack,
                    cfg.rayTracing && cfg.rayTracedReflections, cfg.rayTracing && cfg.rayTracedGI,
                    cfg.rayTracing && cfg.rayTracedShadows, cfg.rayTracing && cfg.rayTracedAO);
            if (cfg.rayTracing && !queued) {
                cfg.rayTracing = false;
                VialumixClient.config().copyFrom(cfg);
                VialumixClient.notify("vialumix.rt.bliss_required");
            }
        }
        // Apply window/graphics settings before Iris rebuilds the rendering pipeline.
        applyBasicGraphics();
        if (!VialumixClient.shaderpacks().apply(cfg.shaderpack)) {
            VialumixClient.notify("vialumix.shaderpack.apply_failed");
            return;
        }

        if (radiance) {
            cfg.rayTracing = true;
            cfg.backend = "vulkan";
            if (cfg.shaderpack != null && cfg.shaderpack.endsWith("/advanced.zip")) {
                int applied = com.vialumix.rt.RadianceRayTracingBridge.applyBlissInspiredPreset();
                if (applied > 0) VialumixClient.notify("vialumix.rt.bliss_preset_applied");
                else VialumixClient.notify("vialumix.rt.preset_apply_failed");
            }
        }
        VialumixClient.config().copyFrom(cfg);
        if (cfg.rayTracing && "iris".equalsIgnoreCase(cfg.backend)) {
            // The Iris shaderpack reload above consumes the option queue prepared before applying it.
        } else if (cfg.rayTracing) {
            if (!VialumixNative.isRendererReady() && !VialumixNative.startRenderer()) {
                cfg.rayTracing = false;
                cfg.backend = "iris";
                VialumixClient.config().copyFrom(cfg);
                VialumixClient.notify("vialumix.rt.backend_missing");
            }
        } else if (VialumixNative.isRendererReady()) {
            VialumixNative.stopRenderer();
        }

        if (cfg.rayTracing && !radiance) VialumixClient.notify("vialumix.rt.screen_space_notice");

        VialumixClient.save();
        field_22787.method_1507(parent);
    }

    private void applyBasicGraphics() {
        class_310 client = class_310.method_1551();
        if (client.field_1690.method_42503().method_41753() != cfg.renderDistance) {
            client.field_1690.method_42503().method_41748(cfg.renderDistance);
        }
        switch (cfg.graphicsQuality) {
            case "fast" -> client.field_1690.method_42534().method_41748(net.minecraft.class_5365.field_25427);
            // Sodium's terrain renderer is not compatible with Minecraft's Fabulous framebuffer path.
            case "fabulous" -> client.field_1690.method_42534().method_41748(net.minecraft.class_5365.field_25428);
            default -> client.field_1690.method_42534().method_41748(net.minecraft.class_5365.field_25428);
        }
        if (!"current".equals(cfg.resolution)) {
            String[] size = cfg.resolution.split("x", 2);
            if (size.length == 2) {
                try {
                    client.method_22683().method_36813(Integer.parseInt(size[0]), Integer.parseInt(size[1]));
                } catch (NumberFormatException ignored) { }
            }
        }
        client.field_1690.method_1640();
    }

    private void addToggle(int x, int y, int width, String label, BoolGetter getter, BoolSetter setter) {
        class_5676<Boolean> toggle = method_37063(class_5676.method_32614().method_32619(getter.get())
                .method_32617(x, y, width, 24, class_2561.method_43471(label), (b, v) -> setter.set(v)));
        if (VialumixNative.isRadianceBackendAvailable()) toggle.field_22763 = false;
    }

    private void cycleResolution() {
        cfg.resolution = switch (cfg.resolution) {
            case "current" -> "1920x1080";
            case "1920x1080" -> "2560x1440";
            case "2560x1440" -> "3840x2160";
            case "3840x2160" -> "1280x720";
            default -> "current";
        };
        resolutionButton.method_25355(class_2561.method_43471("vialumix.graphics.resolution").method_27693(": ").method_10852(resolutionText()));
    }

    private class_2561 resolutionText() {
        return class_2561.method_43471("vialumix.graphics.resolution." + cfg.resolution);
    }

    private void cycleRenderDistance() {
        int[] values = {6, 8, 10, 12, 16, 20, 24, 32};
        int current = 0;
        for (int i = 0; i < values.length; i++) if (values[i] == cfg.renderDistance) current = i;
        cfg.renderDistance = values[(current + 1) % values.length];
        renderDistanceButton.method_25355(class_2561.method_43471("vialumix.graphics.render_distance").method_27693(": ").method_27693(Integer.toString(cfg.renderDistance)));
    }

    private void cycleGraphicsQuality() {
        cfg.graphicsQuality = switch (cfg.graphicsQuality) {
            case "fast" -> "fancy";
            case "fancy" -> "fabulous";
            default -> "fast";
        };
        graphicsQualityButton.method_25355(class_2561.method_43471("vialumix.graphics.quality").method_27693(": ").method_10852(graphicsQualityText()));
    }

    private class_2561 graphicsQualityText() {
        return class_2561.method_43471("vialumix.graphics.quality." + cfg.graphicsQuality);
    }

    private void openShaderpackSelection() {
        VialumixClient.shaderpacks().scan();
        field_22787.method_1507(new ShaderpackSelectionScreen(this, cfg.shaderpack, selected -> {
            cfg.shaderpack = selected;
            updateShaderButton();
        }));
    }

    private void updateShaderButton() {
        shaderButton.method_25355(class_2561.method_43471("vialumix.shaderpack").method_27693(": ").method_27693(VialumixClient.shaderpacks().displayName(cfg.shaderpack)));
    }

    private void cycleUpscaler() {
        cfg.upscaler = switch (cfg.upscaler) {
            case "native" -> VialumixNative.hasDlssRuntime() ? "dlss" : "fsr";
            case "dlss" -> "fsr";
            case "fsr" -> "xess";
            default -> "native";
        };
        dlssButton.method_25355(class_2561.method_43471("vialumix.upscaler").method_27693(": ").method_10852(upscalerText()));
    }

    private class_2561 upscalerText() { return class_2561.method_43471("vialumix.upscaler." + cfg.upscaler); }

    private void cycleDlssQuality() {
        cfg.dlssQuality = switch (cfg.dlssQuality) {
            case "quality" -> "balanced";
            case "balanced" -> "performance";
            case "performance" -> "ultra_performance";
            default -> "quality";
        };
    }

    @Override
    public void method_25419() {
        VialumixClient.save();
        field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 22, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @FunctionalInterface private interface BoolGetter { boolean get(); }
    @FunctionalInterface private interface BoolSetter { void set(boolean value); }
}
