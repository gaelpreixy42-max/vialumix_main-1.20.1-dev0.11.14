package com.vialumix.rt;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4184;

/** Builds a bounded, opaque-block snapshot in camera space for the Vulkan RT scene probe. */
public final class RayTracingWorldCapture {
    private static final int HORIZONTAL_RADIUS = 24;
    private static final int VERTICAL_RADIUS = 16;
    private static final int MAX_TRIANGLES = 500_000;
    private static final class_2350[] FACES = class_2350.values();
    private static final float[][][] FACE_CORNERS = {
            {{0,0,0},{1,0,0},{1,0,1},{0,0,1}}, {{0,1,0},{0,1,1},{1,1,1},{1,1,0}},
            {{0,0,0},{0,1,0},{1,1,0},{1,0,0}}, {{0,0,1},{1,0,1},{1,1,1},{0,1,1}},
            {{0,0,0},{0,0,1},{0,1,1},{0,1,0}}, {{1,0,0},{1,1,0},{1,1,1},{1,0,1}}
    };

    private RayTracingWorldCapture() {}

    public static Scene capture(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return new Scene(new float[0], 0);
        class_4184 camera = client.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        double yaw = Math.toRadians(camera.method_19330());
        double pitch = Math.toRadians(camera.method_19329());
        class_243 forward = new class_243(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)).method_1029();
        class_243 worldUp = new class_243(0, 1, 0);
        class_243 right = worldUp.method_1036(forward).method_1029();
        if (right.method_1027() < 1.0e-6) right = new class_243(1, 0, 0);
        class_243 up = forward.method_1036(right).method_1029();

        int centerX = class_2338.method_49637(cameraPos.field_1352, cameraPos.field_1351, cameraPos.field_1350).method_10263();
        int centerY = class_2338.method_49637(cameraPos.field_1352, cameraPos.field_1351, cameraPos.field_1350).method_10264();
        int centerZ = class_2338.method_49637(cameraPos.field_1352, cameraPos.field_1351, cameraPos.field_1350).method_10260();
        int minY = Math.max(client.field_1687.method_31607(), centerY - VERTICAL_RADIUS);
        int maxY = Math.min(client.field_1687.method_31600(), centerY + VERTICAL_RADIUS);
        class_2338.class_2339 pos = new class_2338.class_2339();
        class_2338.class_2339 neighborPos = new class_2338.class_2339();
        FloatBuilder vertices = new FloatBuilder(32_768);

        for (int y = minY; y < maxY && vertices.triangles < MAX_TRIANGLES; y++) {
            for (int z = centerZ - HORIZONTAL_RADIUS; z <= centerZ + HORIZONTAL_RADIUS && vertices.triangles < MAX_TRIANGLES; z++) {
                for (int x = centerX - HORIZONTAL_RADIUS; x <= centerX + HORIZONTAL_RADIUS && vertices.triangles < MAX_TRIANGLES; x++) {
                    pos.method_10103(x, y, z);
                    class_2680 state = client.field_1687.method_8320(pos);
                    if (!state.method_26216(client.field_1687, pos)) continue;
                    for (class_2350 face : FACES) {
                        neighborPos.method_10103(x + face.method_10148(), y + face.method_10164(), z + face.method_10165());
                        class_2680 neighbor = client.field_1687.method_8320(neighborPos);
                        if (!neighbor.method_26216(client.field_1687, neighborPos)) {
                            appendFace(vertices, x, y, z, face, cameraPos, right, up, forward);
                            if (vertices.triangles >= MAX_TRIANGLES) break;
                        }
                    }
                }
            }
        }
        return new Scene(vertices.toArray(), vertices.triangles);
    }

    private static void appendFace(FloatBuilder out, int x, int y, int z, class_2350 face,
                                   class_243 camera, class_243 right, class_243 up, class_243 forward) {
        float[][] corners = FACE_CORNERS[face.method_10146()];
        addTriangle(out, x, y, z, corners[0], corners[1], corners[2], camera, right, up, forward);
        addTriangle(out, x, y, z, corners[0], corners[2], corners[3], camera, right, up, forward);
    }

    private static void addTriangle(FloatBuilder out, int x, int y, int z, float[] a, float[] b, float[] c,
                                    class_243 camera, class_243 right, class_243 up, class_243 forward) {
        addVertex(out, x + a[0], y + a[1], z + a[2], camera, right, up, forward);
        addVertex(out, x + b[0], y + b[1], z + b[2], camera, right, up, forward);
        addVertex(out, x + c[0], y + c[1], z + c[2], camera, right, up, forward);
        out.triangles++;
    }

    private static void addVertex(FloatBuilder out, double x, double y, double z,
                                  class_243 camera, class_243 right, class_243 up, class_243 forward) {
        double dx = x - camera.field_1352, dy = y - camera.field_1351, dz = z - camera.field_1350;
        out.add((float)(dx * right.field_1352 + dy * right.field_1351 + dz * right.field_1350));
        out.add((float)(dx * up.field_1352 + dy * up.field_1351 + dz * up.field_1350));
        out.add((float)-(dx * forward.field_1352 + dy * forward.field_1351 + dz * forward.field_1350));
    }

    public record Scene(float[] vertices, int triangles) {}

    private static final class FloatBuilder {
        private float[] values;
        private int size;
        private int triangles;
        private FloatBuilder(int initialCapacity) { values = new float[initialCapacity]; }
        private void add(float value) {
            if (size == values.length) values = java.util.Arrays.copyOf(values, values.length * 2);
            values[size++] = value;
        }
        private float[] toArray() { return java.util.Arrays.copyOf(values, size); }
    }
}
