package com.vialumix.rt;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/** Temporary HUD preview for validating Vulkan RT hits against the captured block scene. */
public final class VialumixRayTracingDebugOverlay {
    private static final int PREVIEW_SIZE = 32;
    private static int[] pixels;
    private static int triangleCount;
    private static long visibleUntil;

    private VialumixRayTracingDebugOverlay() {}

    public static void show(byte[] rgba, int width, int height, int triangles) {
        if (rgba == null || rgba.length < width * height * 4) return;
        int[] preview = new int[PREVIEW_SIZE * PREVIEW_SIZE];
        for (int y = 0; y < PREVIEW_SIZE; y++) {
            int sourceY = Math.min(height - 1, (y * height) / PREVIEW_SIZE);
            for (int x = 0; x < PREVIEW_SIZE; x++) {
                int sourceX = Math.min(width - 1, (x * width) / PREVIEW_SIZE);
                int index = (sourceY * width + sourceX) * 4;
                int red = Byte.toUnsignedInt(rgba[index]);
                int green = Byte.toUnsignedInt(rgba[index + 1]);
                int blue = Byte.toUnsignedInt(rgba[index + 2]);
                int alpha = Byte.toUnsignedInt(rgba[index + 3]);
                preview[y * PREVIEW_SIZE + x] = (alpha << 24) | (red << 16) | (green << 8) | blue;
            }
        }
        pixels = preview;
        triangleCount = triangles;
        class_310 client = class_310.method_1551();
        visibleUntil = client.field_1687 == null ? 0 : client.field_1687.method_8510() + 400;
    }

    public static void render(class_332 context, class_310 client) {
        if (pixels == null || client.field_1687 == null || client.field_1724 == null || client.field_1687.method_8510() > visibleUntil) return;
        int x = 10;
        int y = 10;
        int scale = 4;
        int size = PREVIEW_SIZE * scale;
        context.method_25294(x - 4, y - 4, x + size + 4, y + size + 24, 0xB0000000);
        for (int py = 0; py < PREVIEW_SIZE; py++) {
            for (int px = 0; px < PREVIEW_SIZE; px++) {
                context.method_25294(x + px * scale, y + py * scale, x + (px + 1) * scale,
                        y + (py + 1) * scale, pixels[py * PREVIEW_SIZE + px]);
            }
        }
        context.method_27535(client.field_1772,
                class_2561.method_43470("Vialumix Vulkan RT preview • " + triangleCount + " triangles"), x, y + size + 7, 0xFFFFFFFF);
    }
}
