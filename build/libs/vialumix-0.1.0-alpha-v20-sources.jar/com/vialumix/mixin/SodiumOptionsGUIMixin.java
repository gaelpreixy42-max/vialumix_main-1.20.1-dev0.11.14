package com.vialumix.mixin;

import com.vialumix.screen.VialumixScreen;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Replaces Sodium's graphics screen with Vialumix's settings screen. */
@Pseudo
@Mixin(targets = "me.jellysquid.mods.sodium.client.gui.SodiumOptionsGUI")
public abstract class SodiumOptionsGUIMixin {
    @Inject(method = "createScreen", at = @At("HEAD"), cancellable = true)
    private static void vialumix$openSettings(class_437 parent, CallbackInfoReturnable<class_437> cir) {
        cir.setReturnValue(new VialumixScreen(parent));
    }
}
