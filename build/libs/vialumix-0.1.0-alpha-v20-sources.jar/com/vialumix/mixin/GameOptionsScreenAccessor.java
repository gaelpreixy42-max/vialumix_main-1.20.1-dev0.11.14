package com.vialumix.mixin;

import net.minecraft.class_437;
import net.minecraft.class_4667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4667.class)
public interface GameOptionsScreenAccessor {
    @Accessor("parent")
    class_437 vialumix$getParent();
}
