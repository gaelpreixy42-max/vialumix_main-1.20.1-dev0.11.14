package com.vialumix.mixin;

import com.vialumix.screen.VialumixScreen;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_446;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Opens Vialumix directly when Minecraft's graphics button is selected. */
@Mixin(class_446.class)
public abstract class VideoOptionsScreenMixin extends class_437 {
    protected VideoOptionsScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void vialumix$openVialumix(CallbackInfo ci) {
        ci.cancel();
        class_437 parent = ((GameOptionsScreenAccessor) (Object) this).vialumix$getParent();
        field_22787.method_1507(new VialumixScreen(parent));
    }
}
