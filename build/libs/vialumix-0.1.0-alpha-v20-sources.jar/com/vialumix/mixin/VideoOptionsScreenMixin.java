package com.vialumix.mixin;

import com.vialumix.screen.VialumixScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_446;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replaces the first Video Options page with a Vialumix chooser.
 * The original Sodium/Iris video-options screen is still available through
 * the "Minecraft / Sodium" button. A short-lived bypass flag lets the
 * vanilla/Sodium screen initialize normally when opened from the chooser.
 */
@Mixin(class_446.class)
public abstract class VideoOptionsScreenMixin extends class_437 {
    @Unique
    private static final ThreadLocal<Boolean> VIALUMIX_BYPASS = ThreadLocal.withInitial(() -> false);

    protected VideoOptionsScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void vialumix$replaceWithChooser(CallbackInfo ci) {
        if (VIALUMIX_BYPASS.get()) {
            return;
        }

        ci.cancel();
        vialumix$buildChooser();
    }

    @Unique
    private void vialumix$buildChooser() {
        int buttonWidth = 310;
        int buttonHeight = 28;
        int x = (field_22789 - buttonWidth) / 2;
        int y = Math.max(55, field_22790 / 2 - 42);

        method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.video.minecraft"),
                button -> vialumix$openMinecraftGraphics()
        ).method_46434(x, y, buttonWidth, buttonHeight).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.video.vialumix"),
                button -> field_22787.method_1507(new VialumixScreen(this))
        ).method_46434(x, y + 38, buttonWidth, buttonHeight).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43471("gui.done"),
                button -> method_25419()
        ).method_46434(x, y + 82, buttonWidth, 20).method_46431());
    }

    @Unique
    private void vialumix$openMinecraftGraphics() {
        if (field_22787 == null) return;

        class_437 chooser = this;
        VIALUMIX_BYPASS.set(true);
        try {
            field_22787.method_1507(new class_446(chooser, field_22787.field_1690));
        } finally {
            VIALUMIX_BYPASS.set(false);
        }
    }
}
