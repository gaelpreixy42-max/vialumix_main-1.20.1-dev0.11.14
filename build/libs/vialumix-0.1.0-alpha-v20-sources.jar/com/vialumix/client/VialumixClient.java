package com.vialumix.client;

import com.vialumix.config.VialumixConfig;
import com.vialumix.rt.VialumixNative;
import com.vialumix.shader.ShaderpackManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import java.nio.file.Path;

public final class VialumixClient implements ClientModInitializer {
    public static final String MOD_ID = "vialumix";
    private static VialumixConfig config;
    private static ShaderpackManager shaderpacks;

    @Override
    public void onInitializeClient() {
        class_310.method_1551();
        Path root = class_310.method_1551().field_1697.toPath();
        config = VialumixConfig.load(root.resolve("config/vialumix.json"));
        if (VialumixNative.isRadianceBackendAvailable()) {
            // Radiance installs MCVR's world renderer at startup; this artifact is RT-first.
            config.rayTracing = true;
            config.backend = "vulkan";
        }
        shaderpacks = new ShaderpackManager(root.resolve("shaderpacks"));
        shaderpacks.scan();
        VialumixNative.initialize(root.resolve("vialumix"));

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> { save(); VialumixNative.stopRenderer(); });
    }

    public static VialumixConfig config() { return config; }
    public static ShaderpackManager shaderpacks() { return shaderpacks; }

    public static void save() {
        class_310 client = class_310.method_1551();
        if (client != null && config != null) {
            config.save(client.field_1697.toPath().resolve("config/vialumix.json"));
        }
    }

    public static void notify(String key) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) client.field_1724.method_7353(class_2561.method_43471(key), true);
    }
}
