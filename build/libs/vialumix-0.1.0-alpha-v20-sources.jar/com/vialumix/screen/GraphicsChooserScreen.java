package com.vialumix.screen;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** First screen shown when the user opens Minecraft's Graphics button. */
public final class GraphicsChooserScreen extends class_437 {
    private final class_437 parent;

    public GraphicsChooserScreen(class_437 parent) {
        super(class_2561.method_43471("vialumix.graphics.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int width = 360;
        int x = (this.field_22789 - width) / 2;
        int y = Math.max(58, this.field_22790 / 2 - 42);

        method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.graphics.minecraft"),
                b -> field_22787.method_1507(SodiumScreenBridge.openOriginal(this))
        ).method_46434(x, y, width, 28).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.graphics.vialumix"),
                b -> field_22787.method_1507(new VialumixScreen(this))
        ).method_46434(x, y + 38, width, 28).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43471("gui.done"),
                b -> method_25419()
        ).method_46434(x, y + 82, width, 20).method_46431());
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 25, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
