package com.vialumix.screen;

import com.vialumix.client.VialumixClient;
import com.vialumix.config.VialumixConfig;
import com.vialumix.rt.VialumixNative;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;

public final class VialumixScreen extends class_437 {
    private final class_437 parent;
    private final VialumixConfig cfg;
    private final int panelWidth = 420;
    private class_4185 shaderButton;
    private class_5676<Boolean> rtButton;
    private class_4185 dlssButton;

    public VialumixScreen(class_437 parent) {
        super(class_2561.method_43471("vialumix.title"));
        this.parent = parent;
        this.cfg = VialumixClient.config();
    }

    @Override
    protected void method_25426() {
        int left = (field_22789 - panelWidth) / 2;
        int y = 48;

        method_37063(class_4185.method_46430(class_2561.method_43471("vialumix.button.minecraft"), b -> {
            VialumixClient.save();
            field_22787.method_1507(parent);
        }).method_46434(left, y, (panelWidth - 8) / 2, 24).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("vialumix.button.vialumix"), b -> {
            // Already on Vialumix; this button is intentionally non-navigating.
        }).method_46434(left + (panelWidth + 8) / 2, y, (panelWidth - 8) / 2, 24).method_46431());
        y += 36;

        List<String> packs = VialumixClient.shaderpacks().packs();
        shaderButton = method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.shaderpack")
                        .method_27693(": ")
                        .method_27693(VialumixClient.shaderpacks().displayName(cfg.shaderpack)),
                b -> cycleShaderpack(packs)
        ).method_46434(left, y, panelWidth, 24).method_46431());
        y += 31;

        rtButton = method_37063(class_5676.method_32614()
                .method_32619(cfg.rayTracing)
                .method_32617(left, y, panelWidth, 24, class_2561.method_43471("vialumix.ray_tracing"), (button, value) -> {
                    if (value) {
                        if (!VialumixNative.supportsRayTracing() || !VialumixNative.startRenderer()) {
                            button.method_32605(false);
                            VialumixClient.notify("vialumix.rt.backend_missing");
                            return;
                        }
                    } else {
                        VialumixNative.stopRenderer();
                    }
                    cfg.rayTracing = value;
                    cfg.backend = value ? "vulkan" : "iris";
                }));
        y += 31;

        y = addToggle(left, y, "vialumix.rt.shadows", () -> cfg.rayTracedShadows, v -> cfg.rayTracedShadows = v);
        y = addToggle(left, y, "vialumix.rt.reflections", () -> cfg.rayTracedReflections, v -> cfg.rayTracedReflections = v);
        y = addToggle(left, y, "vialumix.rt.gi", () -> cfg.rayTracedGI, v -> cfg.rayTracedGI = v);
        y = addToggle(left, y, "vialumix.rt.ao", () -> cfg.rayTracedAO, v -> cfg.rayTracedAO = v);
        y = addToggle(left, y, "vialumix.rt.denoiser", () -> cfg.denoiser, v -> cfg.denoiser = v);
        y = addToggle(left, y, "vialumix.rt.reconstruction", () -> cfg.rayReconstruction, v -> {
            if (v && !VialumixNative.supportsRayReconstruction()) {
                VialumixClient.notify("vialumix.dlss.rr_missing");
                return;
            }
            cfg.rayReconstruction = v;
        });

        dlssButton = method_37063(class_4185.method_46430(
                class_2561.method_43471("vialumix.upscaler").method_27693(": ").method_10852(upscalerText()),
                b -> cycleUpscaler()
        ).method_46434(left, y + 6, panelWidth, 24).method_46431());
        y += 37;

        method_37063(class_4185.method_46430(class_2561.method_43471("vialumix.dlss.quality").method_27693(": ").method_27693(cfg.dlssQuality), b -> cycleDlssQuality())
                .method_46434(left, y, panelWidth, 24).method_46431());
        y += 31;

        method_37063(class_5676.method_32614()
                .method_32619(cfg.frameGeneration)
                .method_32617(left, y, panelWidth, 24, class_2561.method_43471("vialumix.frame_generation"), (b, value) -> {
                    if (value && !VialumixNative.supportsFrameGeneration()) {
                        VialumixClient.notify("vialumix.dlss.fg_missing");
                        b.method_32605(false);
                        return;
                    }
                    cfg.frameGeneration = value;
                }));
        y += 40;

        method_37063(class_4185.method_46430(class_2561.method_43471("vialumix.apply"), b -> {
            VialumixClient.shaderpacks().apply(cfg.shaderpack);
            method_25419();
        })
                .method_46434(left, y, (panelWidth - 8) / 2, 24).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), b -> {
            field_22787.method_1507(parent);
        }).method_46434(left + (panelWidth + 8) / 2, y, (panelWidth - 8) / 2, 24).method_46431());
    }

    private int addToggle(int x, int y, String label, BoolGetter getter, BoolSetter setter) {
        method_37063(class_5676.method_32614().method_32619(getter.get())
                .method_32617(x, y, panelWidth, 24, class_2561.method_43471(label), (b, v) -> setter.set(v)));
        return y + 31;
    }

    private void cycleShaderpack(List<String> packs) {
        if (packs.isEmpty()) { cfg.shaderpack = ""; updateShaderButton(); return; }
        int current = packs.indexOf(cfg.shaderpack);
        cfg.shaderpack = packs.get((current + 1 + packs.size()) % packs.size());
        updateShaderButton();
    }

    private void updateShaderButton() {
        shaderButton.method_25355(class_2561.method_43471("vialumix.shaderpack").method_27693(": ").method_27693(VialumixClient.shaderpacks().displayName(cfg.shaderpack)));
    }

    private void cycleUpscaler() {
        cfg.upscaler = switch (cfg.upscaler) {
            case "native" -> VialumixNative.hasDlssRuntime() ? "dlss" : "fsr";
            case "dlss" -> "fsr";
            case "fsr" -> "xess";
            default -> "native";
        };
        dlssButton.method_25355(class_2561.method_43471("vialumix.upscaler").method_27693(": ").method_10852(upscalerText()));
    }

    private class_2561 upscalerText() {
        return class_2561.method_43471("vialumix.upscaler." + cfg.upscaler);
    }

    private void cycleDlssQuality() {
        cfg.dlssQuality = switch (cfg.dlssQuality) {
            case "quality" -> "balanced";
            case "balanced" -> "performance";
            case "performance" -> "ultra_performance";
            default -> "quality";
        };
    }

    @Override
    public void method_25419() {
        VialumixClient.save();
        field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 22, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @FunctionalInterface private interface BoolGetter { boolean get(); }
    @FunctionalInterface private interface BoolSetter { void set(boolean value); }
}
