package com.vialumix.screen;

import com.vialumix.client.VialumixClient;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_6379;

/** Lists shaderpacks discovered by Iris and lets the user choose one for the next Apply action. */
public final class ShaderpackSelectionScreen extends class_437 {
    private final class_437 parent;
    private final Consumer<String> onSelect;
    private final List<String> packs;
    private final List<PackEntry> entries = new ArrayList<>();
    private String selectedPack;
    private PackList packList;

    public ShaderpackSelectionScreen(class_437 parent, String selectedPack, Consumer<String> onSelect) {
        super(class_2561.method_43471("vialumix.shaderpack.select"));
        this.parent = parent;
        this.selectedPack = selectedPack == null ? "" : selectedPack;
        this.onSelect = onSelect;
        this.packs = new ArrayList<>(VialumixClient.shaderpacks().packs());
    }

    @Override
    protected void method_25426() {
        int listTop = 48;
        int listBottom = field_22790 - 100;
        packList = new PackList(field_22787, field_22789, Math.max(80, listBottom - listTop), listTop, listBottom, 28);
        packList.method_31322(false);
        packList.method_31323(false);

        entries.clear();
        entries.add(new PackEntry(""));
        for (String pack : packs) {
            entries.add(new PackEntry(pack));
        }
        for (PackEntry entry : entries) {
            packList.addPackEntry(entry);
        }
        method_37063(packList);

        int buttonWidth = Math.min(180, field_22789 - 40);
        int x = (field_22789 - buttonWidth) / 2;
        int y = field_22790 - 76;
        method_37063(class_4185.method_46430(class_2561.method_43471("vialumix.shaderpack.choose"), button -> {
            onSelect.accept(selectedPack);
            field_22787.method_1507(parent);
        }).method_46434(x, y, buttonWidth, 20).method_46431());

        int actionWidth = Math.min(140, (field_22789 - 48) / 2);
        int actionGap = 8;
        int actionX = (field_22789 - (actionWidth * 2 + actionGap)) / 2;
        int actionY = field_22790 - 30;
        method_37063(class_4185.method_46430(class_2561.method_43471("vialumix.shaderpack.disable"), button -> {
            selectedPack = "";
            onSelect.accept("");
            field_22787.method_1507(parent);
        }).method_46434(actionX, actionY, actionWidth, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), button -> field_22787.method_1507(parent))
                .method_46434(actionX + actionWidth + actionGap, actionY, actionWidth, 20).method_46431());
    }

    private void select(String pack) {
        selectedPack = pack;
        for (PackEntry entry : entries) {
            entry.updateMessage();
        }
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 20, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private final class PackList extends class_4265<PackEntry> {
        private PackList(class_310 client, int width, int height, int top, int bottom, int itemHeight) {
            super(client, width, height, top, bottom, itemHeight);
            method_25333((width - Math.min(420, width - 40)) / 2);
        }

        @Override
        public int method_25322() {
            return Math.min(420, field_22742 - 40);
        }

        private void addPackEntry(PackEntry entry) {
            method_25321(entry);
        }
    }

    private final class PackEntry extends class_4265.class_4266<PackEntry> {
        private final String pack;
        private final class_4185 button;

        private PackEntry(String pack) {
            this.pack = pack;
            this.button = class_4185.method_46430(class_2561.method_43473(), ignored -> select(pack))
                    .method_46434(0, 0, 300, 22)
                    .method_46431();
            updateMessage();
        }

        private void updateMessage() {
            String name = pack.isEmpty()
                    ? class_2561.method_43471("vialumix.shaderpack.none").getString()
                    : VialumixClient.shaderpacks().displayName(pack);
            String marker = selectedPack.equals(pack) ? "✓ " : "";
            button.method_25355(class_2561.method_43470(marker + name));
        }

        @Override
        public List<? extends class_364> method_25396() {
            return List.of(button);
        }

        @Override
        public List<? extends class_6379> method_37025() {
            return List.of(button);
        }

        @Override
        public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight,
                           int mouseX, int mouseY, boolean hovered, float delta) {
            button.method_48229(x, y + 2);
            button.method_25358(entryWidth);
            button.method_25394(context, mouseX, mouseY, delta);
        }
    }
}
